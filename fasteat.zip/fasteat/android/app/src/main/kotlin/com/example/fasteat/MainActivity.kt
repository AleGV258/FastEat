package com.example.fasteat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
